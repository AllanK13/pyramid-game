# Pyramid Scheme - Development TODO

## 🚀 High Priority

- [ ] Balance production rates and pyramid requirements
  - Current: 10 clicks → 1 stone, 10 stones → 1 pyramid, 10 pyramids → 1 hire
  - May need tuning for proper game pacing

## 🎮 Core Gameplay

- [ ] Make AP upgrade purchase buttons functional
  - Wire up click handlers for each upgrade card
  - Deduct AP cost when purchased
  - Increment upgrade level
  - Apply upgrade effects immediately

- [ ] Add offline progress calculation
  - Track time away from game
  - Calculate production during offline time
  - Apply offline speed multiplier from config
  - Show "welcome back" summary

## 💾 Save/Load System

- [ ] Test save/load functionality
  - Verify all game state persists correctly
  - Test autosave (currently 30 seconds)
  - Test manual save on page unload

- [ ] Add save import/export UI
  - Button to export save as text
  - Button to import save from text
  - Button to delete save (with confirmation)

## 🎨 UI/UX Improvements

- Add artwork
  - avatar
  - stone
  - sculpted stone pile
  - pyramids
  - alien ship

- [ ] Add visual feedback for worker hiring
  - Animation when hire count increases
  - Notification when investor reaches max hires
  - Particle effects for pyramid creation

- [ ] Add tab for game settings
  - Toggle autosave
  - Adjust autosave frequency
  - Toggle debug mode

## 🐛 Bug Fixes



## ✨ Nice-to-Have Features

- [ ] Add sound effects
  - Click sound for sculpting
  - Success sound for pyramid completion
  - Ding sound for investor hire

- [ ] Add achievements system
  - First pyramid
  - First investor hired
  - Reach 1000 pyramids
  - Max out an investor (5/5 hires)

- [ ] Add visual pyramid counter
  - Stack of pyramid icons
  - Larger display for big numbers

- [ ] Add worker efficiency display
  - Show how much each investor is contributing
  - Highlight most productive investor

## 🔧 Code Quality

- [ ] Remove duplicate Config objects
  - CONFIG vs Config in config.js
  - Consolidate to single object

- [ ] Clean up unused worker.js module
  - Currently has old tier-based logic
  - Either remove or repurpose for new system

- [ ] Add JSDoc comments
  - Document all public functions
  - Add parameter and return type info

## 📝 Documentation

- [ ] Write gameplay guide
  - How to play
  - Explain pyramid scheme mechanics
  - Prestige system explanation

- [ ] Create changelog
  - Track version history
  - Document major changes

## 🎯 Future Ideas

- [ ] Add more investor tiers (currently 5)
- [ ] Add prestige currency multipliers
- [ ] Add idle challenges/events
- [ ] Add different themes/skins
- [ ] Add statistics page (lifetime stats)
- [ ] Add leaderboard (local high scores)

---

## Notes

- Game is currently at v0.01
- Using CONFIG.WORKER_CLICK_INTERVAL for production speed
- Stats tab shows real-time progress
- Debug mode enabled by default (Config.debug_mode = true)

## Quick Commands

- **Test investor hiring**: Use "+10 Pyramids" debug button repeatedly
- **Test max hires**: Watch investor count go from 0→1→2→3→4→5
- **Test prestige**: Manually call `Prestige.prestige()` in console (once implemented)
