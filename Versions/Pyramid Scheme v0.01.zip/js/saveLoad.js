// Save/Load System - Persistence and offline progress

const SaveLoad = {
  SAVE_KEY: 'pyramidGame_save',
  autosaveInterval: null,
  
  // Initialize autosave
  startAutosave: function() {
    if (this.autosaveInterval) {
      clearInterval(this.autosaveInterval);
    }
    
    this.autosaveInterval = setInterval(() => {
      this.save();
    }, CONFIG.AUTOSAVE_INTERVAL);
    
    console.log(`Autosave started (every ${CONFIG.AUTOSAVE_INTERVAL / 1000 / 60} minutes)`);
  },
  
  // Stop autosave
  stopAutosave: function() {
    if (this.autosaveInterval) {
      clearInterval(this.autosaveInterval);
      this.autosaveInterval = null;
    }
  },
  
  // Save game to localStorage
  save: function() {
    if (GameState && GameState.state) {
      try {
        const saveData = {
          version: 1,
          timestamp: Date.now(),
          gameState: {
            resources: { ...GameState.resources },
            workers: { ...GameState.workers },
            workerProduction: { ...GameState.workerProduction },
            upgrades: { ...GameState.upgrades },
            timestamps: { ...GameState.timestamps },
            stats: { ...GameState.stats },
            flags: { ...GameState.flags }
          }
        };
        
        const saveString = JSON.stringify(saveData);
        localStorage.setItem(this.SAVE_KEY, saveString);
        
        GameState.timestamps.lastSave = Date.now();
        
        console.log('💾 Game saved');
        return true;
      } catch (error) {
        console.error('Failed to save game:', error);
        return false;
      }
    }
  },
  
  // Load game from localStorage
  load: function() {
    try {
      const saveString = localStorage.getItem(this.SAVE_KEY);
      
      if (!saveString) {
        console.log('No save data found, starting new game');
        return false;
      }
      
      const saveData = JSON.parse(saveString);
      
      // Validate save data
      if (!saveData.gameState) {
        console.error('Invalid save data');
        return false;
      }
      
      // Load data into GameState
      GameState.resources = { ...saveData.gameState.resources };
      GameState.workers = { ...saveData.gameState.workers };
      GameState.workerProduction = { ...saveData.gameState.workerProduction };
      GameState.upgrades = { ...saveData.gameState.upgrades };
      GameState.timestamps = { ...saveData.gameState.timestamps };
      GameState.stats = { ...saveData.gameState.stats };
      GameState.flags = { ...saveData.gameState.flags };
      
      console.log('📂 Game loaded from save:', GameState.state);
      
      return true;
    } catch (error) {
      console.error('Failed to load game:', error);
      return false;
    }
  },
  
  // Export save data as string
  exportSave: function() {
    const saveString = localStorage.getItem(this.SAVE_KEY);
    if (!saveString) return null;
    
    return btoa(saveString); // Base64 encode
  },
  
  // Import save data from string
  importSave: function(saveString) {
    try {
      const decoded = atob(saveString); // Base64 decode
      const saveData = JSON.parse(decoded);
      
      // Validate
      if (!saveData.gameState) {
        throw new Error('Invalid save data');
      }
      
      // Save to localStorage
      localStorage.setItem(this.SAVE_KEY, decoded);
      
      // Load the imported save
      this.load();
      
      console.log('Save imported successfully');
      return true;
    } catch (error) {
      console.error('Failed to import save:', error);
      return false;
    }
  },
  
  // Delete save data
  deleteSave: function() {
    if (confirm('Are you sure you want to delete your save? This cannot be undone!')) {
      localStorage.removeItem(this.SAVE_KEY);
      console.log('Save deleted');
      
      // Reset to new game
      this.resetGame();
      return true;
    }
    return false;
  },
  
  // Reset to a completely new game
  resetGame: function() {
    // Reset all game state
    GameState.resources = {
      stoneProgress: 0,
      sculptedStones: 0,
      pyramids: 0,
      alienPoints: 0
    };
    
    for (let i = 1; i <= 10; i++) {
      GameState.workers[`tier${i}`] = 0;
      GameState.workerProduction[`tier${i}Stones`] = 0;
      GameState.workerProduction[`tier${i}Pyramids`] = 0;
    }
    
    GameState.upgrades = {
      startingStones: 0,
      startingPyramids: 0,
      hireCapacity: 0,
      workerSpeedOnline: 0,
      workerSpeedOffline: 0,
      apGainBonus: 0
    };
    
    GameState.timestamps = {
      lastTick: Date.now(),
      lastSave: Date.now(),
      gameStart: Date.now()
    };
    
    GameState.stats = {
      totalClicks: 0,
      totalStonesCompleted: 0,
      totalPyramidsBuilt: 0,
      totalAPEarned: 0,
      prestigeCount: 0,
      totalPlayTime: 0
    };
    
    GameState.flags = {
      hasWon: false,
      isPaused: false
    };
    
    // Update UI
    if (typeof UI !== 'undefined') {
      UI.update();
    }
    
    console.log('Game reset to new state');
  }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = SaveLoad;
}

console.log('✅ SaveLoad module loaded');
