// Game Engine - Main game loop and logic

const GameEngine = {
  tickInterval: null,

  // Start the game loop
  start() {
    console.log('⚙️ GameEngine.start()');
    
    // Start game loop (runs every 100ms)
    this.tickInterval = setInterval(() => {
      this.tick();
    }, 100);
    
    console.log('✅ GameEngine started');
  },

  // Stop the game loop
  stop() {
    if (this.tickInterval) {
      clearInterval(this.tickInterval);
      this.tickInterval = null;
    }
  },

  // Main game tick
  tick() {
    // Update worker production
    this.updateWorkerProduction();
    
    // Auto-convert stones to pyramids
    this.convertStonesToPyramids();
    
    // Update UI to show progress
    if (UI && UI.update) {
      UI.update();
    }
  },

  // Player clicks the main sculpt button
  clickStone() {
    GameState.state.stoneProgress = (GameState.state.stoneProgress || 0) + 1;
    
    const required = CONFIG.CLICKS_PER_STONE || 10;
    
    // Automatically convert excess stone progress to sculpted stones
    while (GameState.state.stoneProgress >= required) {
      GameState.state.stoneProgress -= required;
      GameState.state.sculptedStones = (GameState.state.sculptedStones || 0) + 1;
    }
    
    this.convertStonesToPyramids();
    UI.update();
  },

  // Convert player's sculpted stones to pyramids
  convertStonesToPyramids() {
    const stonesPerPyramid = CONFIG.STONES_PER_PYRAMID || 10;
    const sculptedStones = GameState.state.sculptedStones || 0;
    
    if (sculptedStones >= stonesPerPyramid) {
      const pyramidsToAdd = Math.floor(sculptedStones / stonesPerPyramid);
      GameState.state.pyramids = (GameState.state.pyramids || 0) + pyramidsToAdd;
      GameState.state.sculptedStones = sculptedStones % stonesPerPyramid;
      UI.update();
    }
  },

  updateWorkerProduction() {
    if (!GameState.state.workers) return;
    
    const now = Date.now();
    const clicksPerStone = CONFIG.CLICKS_PER_STONE || 10;
    const stonesPerPyramid = CONFIG.STONES_PER_PYRAMID || 10;
    const pyramidsPerHire = CONFIG.PYRAMIDS_PER_HIRE || 10;
    const maxHires = CONFIG.MAX_HIRES_BASE || 5; // Maximum workers each investor can hire
    
    // Get speed multiplier from AP upgrades
    const speedMultiplier = 1.0 + (GameState.state.apUpgrades?.workerSpeedOnline || 0) * 0.01;
    
    // Workers click based on WORKER_CLICK_INTERVAL (default 1 click per second)
    const workerClickInterval = CONFIG.WORKER_CLICK_INTERVAL || 1000;
    const clicksPerSecond = 1000 / workerClickInterval;
    
    // Process each worker tier
    for (let i = 1; i <= 5; i++) {
      const workerId = i.toString();
      const worker = GameState.state.workers[workerId];
      
      // Worker must be unlocked to produce
      if (!worker || !worker.unlocked) continue;
      
      // Check if this worker has reached max hires - if so, they stop producing
      const currentHires = worker.hires || 0;
      if (currentHires >= maxHires) {
        // Worker has maxed out their hires, they stop producing
        continue;
      }
      
      // Calculate time since last tick for this worker
      const deltaTime = now - (worker.lastTickTime || now);
      worker.lastTickTime = now;
      
      // Only the investor themselves clicks (not their sub-workers - they're invisible/background)
      const totalActiveWorkers = 1;
      
      // Calculate clicks: (time in seconds) * (clicks per second) * (number of workers) * (speed multiplier)
      const secondsElapsed = deltaTime / 1000;
      const clicksToAdd = secondsElapsed * clicksPerSecond * totalActiveWorkers * speedMultiplier;
      
      // Add clicks to stone progress
      worker.stoneProgress = (worker.stoneProgress || 0) + clicksToAdd;
      
      // Convert stone progress to sculpted stones
      while (worker.stoneProgress >= clicksPerStone) {
        worker.stoneProgress -= clicksPerStone;
        worker.sculptedStones = (worker.sculptedStones || 0) + 1;
      }
      
      // Convert sculpted stones to pyramids
      while (worker.sculptedStones >= stonesPerPyramid) {
        worker.sculptedStones -= stonesPerPyramid;
        worker.pyramids = (worker.pyramids || 0) + 1;
      }
      
      // Check if worker can hire invisible background workers based on total pyramids
      // 10 pyramids = 1 hire, 20 pyramids = 2 hires, etc.
      const totalPyramids = worker.pyramids || 0;
      const shouldHaveHires = Math.floor(totalPyramids / pyramidsPerHire);
      const targetHires = Math.min(shouldHaveHires, maxHires);
      
      // Update hires if needed (they accumulated enough pyramids)
      if (currentHires < targetHires) {
        const hiresToMake = targetHires - currentHires;
        worker.hires = targetHires;
        
        console.log(`Investor ${workerId} hired ${hiresToMake} invisible worker(s) (total pyramids: ${totalPyramids}, now has ${targetHires}/5 workers)`);
      }
    }
  }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = GameEngine;
}

console.log('✅ GameEngine module loaded');
