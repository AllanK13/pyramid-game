// Worker System - Pure Mathematical Calculations
// No individual worker objects, just aggregate production math

const Workers = {
  // Calculate total clicks per tick from all workers
  calculateTotalWorkerClicks: function(deltaTime, speedMultiplier = 1.0) {
    const ticksPerSecond = 1000 / CONFIG.WORKER_CLICK_INTERVAL;
    const secondsElapsed = deltaTime / 1000;
    const baseClicksPerWorker = ticksPerSecond * secondsElapsed * speedMultiplier;
    
    let totalClicks = 0;
    
    // Calculate clicks from each tier
    for (let tier = 1; tier <= 10; tier++) {
      const workerCount = GameState.workers[`tier${tier}`];
      if (workerCount > 0) {
        totalClicks += workerCount * baseClicksPerWorker;
      }
    }
    
    return totalClicks;
  },
  
  // Process worker production and conversions
  processWorkerProduction: function(deltaTime, speedMultiplier = 1.0) {
    const totalClicks = this.calculateTotalWorkerClicks(deltaTime, speedMultiplier);
    
    if (totalClicks <= 0) return;
    
    // Distribute clicks across tiers proportionally
    const tierDistribution = this.calculateTierDistribution();
    
    for (let tier = 1; tier <= 10; tier++) {
      const tierKey = `tier${tier}`;
      const workerCount = GameState.workers[tierKey];
      
      if (workerCount > 0) {
        const tierClicks = totalClicks * tierDistribution[tier];
        this.processClicksForTier(tier, tierClicks);
      }
    }
  },
  
  // Calculate what percentage of total clicks each tier contributes
  calculateTierDistribution: function() {
    const distribution = {};
    let totalWorkers = 0;
    
    for (let tier = 1; tier <= 10; tier++) {
      totalWorkers += GameState.workers[`tier${tier}`];
    }
    
    if (totalWorkers === 0) {
      for (let tier = 1; tier <= 10; tier++) {
        distribution[tier] = 0;
      }
      return distribution;
    }
    
    for (let tier = 1; tier <= 10; tier++) {
      const workerCount = GameState.workers[`tier${tier}`];
      distribution[tier] = workerCount / totalWorkers;
    }
    
    return distribution;
  },
  
  // Process clicks for a specific tier
  processClicksForTier: function(tier, clicks) {
    const tierKey = `tier${tier}`;
    const stonesKey = `${tierKey}Stones`;
    const pyramidsKey = `${tierKey}Pyramids`;
    
    // Add clicks to stone production for this tier
    let remainingClicks = clicks;
    
    while (remainingClicks >= CONFIG.CLICKS_PER_STONE) {
      // Complete a stone
      GameState.workerProduction[stonesKey]++;
      GameState.stats.totalStonesCompleted++;
      remainingClicks -= CONFIG.CLICKS_PER_STONE;
      
      // Check if we can form a pyramid
      if (GameState.workerProduction[stonesKey] >= CONFIG.STONES_PER_PYRAMID) {
        GameState.workerProduction[stonesKey] -= CONFIG.STONES_PER_PYRAMID;
        GameState.workerProduction[pyramidsKey]++;
        GameState.resources.pyramids++;
        GameState.stats.totalPyramidsBuilt++;
      }
    }
    
    // Store fractional clicks for next tick (optional, for precision)
    // For now, we'll discard fractional clicks
  },
  
  // Check if any tier can hire new workers and do so
  processWorkerHiring: function() {
    for (let tier = 1; tier <= 9; tier++) { // Tier 10 can't hire (max depth)
      const tierKey = `tier${tier}`;
      const pyramidsKey = `${tierKey}Pyramids`;
      const nextTierKey = `tier${tier + 1}`;
      
      const workerCount = GameState.workers[tierKey];
      if (workerCount === 0) continue; // No workers at this tier
      
      const pyramidsProduced = GameState.workerProduction[pyramidsKey];
      const maxHires = GameState.getMaxHiresForTier(tier + 1);
      const currentHires = GameState.workers[nextTierKey];
      
      // Check if this tier has produced enough pyramids to hire
      // Each worker at this tier can hire independently
      const pyramidsPerHire = CONFIG.PYRAMIDS_PER_HIRE;
      const possibleHires = Math.floor(pyramidsProduced / pyramidsPerHire);
      
      if (possibleHires > 0 && currentHires < maxHires * workerCount) {
        // Calculate how many we can actually hire
        const maxPossibleHires = (maxHires * workerCount) - currentHires;
        const hiresToMake = Math.min(possibleHires, maxPossibleHires);
        
        if (hiresToMake > 0) {
          // Hire workers
          GameState.workers[nextTierKey] += hiresToMake;
          GameState.workerProduction[pyramidsKey] -= hiresToMake * pyramidsPerHire;
        }
      }
    }
  },
  
  // Get total worker count across all tiers
  getTotalWorkerCount: function() {
    let total = 0;
    for (let tier = 1; tier <= 10; tier++) {
      total += GameState.workers[`tier${tier}`];
    }
    return total;
  },
  
  // Get production rate summary for display
  getProductionRates: function() {
    const speedMultiplier = GameState.getWorkerSpeedMultiplier(false);
    const clicksPerSecond = this.calculateTotalWorkerClicks(1000, speedMultiplier);
    const stonesPerSecond = clicksPerSecond / CONFIG.CLICKS_PER_STONE;
    const pyramidsPerSecond = stonesPerSecond / CONFIG.STONES_PER_PYRAMID;
    
    return {
      clicksPerSecond: clicksPerSecond,
      stonesPerSecond: stonesPerSecond,
      pyramidsPerSecond: pyramidsPerSecond
    };
  },
  
  // Check if player can hire a tier 1 worker
  canHireTier1Worker: function() {
    const cost = CONFIG.PYRAMIDS_PER_HIRE;
    const maxHires = GameState.getMaxHiresForTier(1);
    const currentHires = GameState.workers.tier1;
    
    return GameState.resources.pyramids >= cost && currentHires < maxHires;
  },
  
  // Hire a tier 1 worker (player action)
  hireTier1Worker: function() {
    if (this.canHireTier1Worker()) {
      const cost = CONFIG.PYRAMIDS_PER_HIRE;
      GameState.resources.pyramids -= cost;
      GameState.workers.tier1++;
      return true;
    }
    return false;
  },
  
  // Workers production logic will go here
  processProduction: function() {
    // Production logic here
  }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = Workers;
}

console.log('✅ Workers module loaded');
