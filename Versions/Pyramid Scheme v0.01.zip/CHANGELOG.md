# Changelog

All notable changes to Pyramid Scheme will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### To Do
- Implement recursive investor hiring (investors hire next tier)
- Make AP upgrade purchase buttons functional
- Add offline progress calculation
- Add prestige/AP selling system
- Add visual feedback for hiring and pyramid creation
- Add sound effects
- Add achievements system

---

## [0.01] - 2024-01-XX (Initial Release)

### Added
- **Core Gameplay**
  - Manual stone sculpting by clicking the stone button
  - Automatic conversion: 10 clicks → 1 stone → 10 stones = 1 pyramid
  - 5 investor tiers with unlock requirements (10, 20, 30, 40, 50 pyramids)
  - Investors automatically sculpt stones when hired
  - Investors hire invisible sub-workers (0-5 max) based on pyramid count
  - Investors stop producing once they reach 5 sub-workers

- **User Interface**
  - Three-tab navigation: Production, Stats, AP Store
  - **Production Tab**:
    - Sky section with animated sun and rays
    - Desert section with player character and stone button
    - Sculpted stones display (progress toward next pyramid)
    - Pyramid counter
    - Workers panel showing 5 investor rows with hire buttons
    - Each investor row displays: avatar, sub-workers count, pyramids made
  - **Stats Tab**:
    - Total pyramids across all investors
    - Real-time pyramids per second calculation
    - Player progress (stone progress, sculpted stones, pyramids)
    - Individual investor statistics in 2-column grid
    - All stats update live (10 times per second)
  - **AP Store Tab**:
    - 6 upgrades available (currently not purchasable):
      - Starting Sculpted Stones
      - Legacy Pyramids
      - Investor Speed Training
      - Increased Hire Capacity
      - Offline Efficiency
      - Alien Bargaining
    - Displays cost, current level, and effects for each upgrade

- **Visual Design**
  - Dark theme with blue/purple gradients
  - Golden accent color for important elements
  - Animated sun with rays in sky section
  - Desert gradient background
  - Styled cards and boxes with shadows and gradients
  - Responsive design for mobile and desktop

- **Debug Features**
  - Debug menu with quick-add buttons (enabled by default)
  - Debug display showing live game state
  - Buttons to add: stone clicks, sculpted stones, pyramids, AP
  - Real-time monitoring of all investors

- **Game Systems**
  - Modular JavaScript architecture (7 separate modules)
  - Configuration system (CONFIG object) with all tunable parameters
  - Game state management with centralized state object
  - Game loop running at 100ms intervals (10 ticks per second)
  - Autosave system (every 60 seconds)
  - localStorage persistence

- **Configuration**
  - 10 clicks = 1 sculpted stone
  - 10 sculpted stones = 1 pyramid
  - 10 pyramids = 1 sub-worker hire
  - Maximum 5 sub-workers per investor
  - 1 second interval per investor click (configurable)
  - Worker speed affected by AP upgrades (1% per level)

### Technical Details
- **Files**:
  - `index.html` - Main game file with embedded CSS
  - `js/config.js` - Configuration and constants
  - `js/gameState.js` - Central state management
  - `js/gameEngine.js` - Game loop and production logic
  - `js/workers.js` - Worker calculation system (legacy, unused)
  - `js/prestige.js` - Prestige system (placeholder)
  - `js/saveLoad.js` - Save/load system (placeholder)
  - `js/ui.js` - UI updates and event handlers
  - `TODO.md` - Development task tracker
  - `CHANGELOG.md` - This file

- **Browser Compatibility**: Modern browsers with ES6 support
- **No Dependencies**: Pure vanilla JavaScript, no frameworks required

### Known Issues
- AP upgrade purchases not yet implemented
- Prestige/AP selling system not yet functional
- Offline progress calculation not implemented
- No sound effects
- Workers module contains unused legacy code
- Duplicate CONFIG/Config objects consolidated but some references may remain

### Notes
- Initial proof-of-concept implementation
- Focus on core gameplay loop and visual design
- Debug mode enabled for testing and balancing
- Game is playable but lacks progression depth

---

## Version History Summary

- **v0.01** - Initial implementation with core gameplay, UI, and investor system

[Unreleased]: https://github.com/yourusername/pyramid-scheme/compare/v0.01...HEAD
[0.01]: https://github.com/yourusername/pyramid-scheme/releases/tag/v0.01
